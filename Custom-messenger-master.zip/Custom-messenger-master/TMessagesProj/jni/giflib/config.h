
// giflib config.h

#ifndef GIF_CONFIG_H_DEFINED
#define GIF_CONFIG_H_DEFINED

#include <sys/types.h>
#define HAVE_STDINT_H
#define HAVE_FCNTL_H

typedef uint32_t UINT32;

#endif
