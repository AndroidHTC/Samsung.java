#include <stdio.h>

void fakeFunction() {
    printf("some androids has buggy native loader, so i should check size of libs in java to know that native library is correct. So each changed native library should has diffrent size in different app versions. This function will increase lib size for few bytes :)");
    printf("");
}
