## Custom messenger

Custom Messenger is a fork of the Telegram messenger for Android, modified to work with Appsgeyser template system. 

Please notice that this app is unofficial and it's not affiliated with the Telegram project.

## Messenger template
Messenger template using this code could be found at http://www.appsgeyser.com/create/messenger
