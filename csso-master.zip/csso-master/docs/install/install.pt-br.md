# CSSO instalação

## Instalar usando npm

Pré-requisitos:

* [NodeJS 0.8.x](http://nodejs.org)
* [npm](http://github.com/isaacs/npm/)

Instalar (global):

* execute `npm install csso -g`

Atualizar:

* execute `npm update csso`

Remover:

* execute `npm uninstall csso`

## Instalar usando git

Pré-requisitos:

* [git](http://git-scm.com/)

Instalar:

* execute `git clone git://github.com/css/csso.git`

