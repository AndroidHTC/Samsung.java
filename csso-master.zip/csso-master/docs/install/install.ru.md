# Установка CSSO

## Установка с помощью npm

Предварительные требования:

* [NodeJS 0.8.x](http://nodejs.org)
* [npm](http://github.com/isaacs/npm/)

Установка (глобально):

* выполнить `npm install csso -g`

Обновление:

* выполнить `npm update csso`

Удаление:

* выполнить `npm uninstall csso`

## Установка с помощью git

Предварительные требования:

* [git](http://git-scm.com/)

Установка:

* выполнить `git clone git://github.com/css/csso.git`

