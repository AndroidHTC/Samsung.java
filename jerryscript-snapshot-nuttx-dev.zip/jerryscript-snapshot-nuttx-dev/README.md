## JerryScript

You can find project details in [wiki](http://samsung.github.io/jerryscript/ "Jerry Script").
