#! /bin/sh

cd `dirname "$0"`

# -d --warnings=all
autoreconf  -v -f -i

cd -

