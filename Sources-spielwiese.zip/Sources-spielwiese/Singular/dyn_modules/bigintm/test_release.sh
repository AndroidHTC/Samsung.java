#!/bin/sh

export SINGULAR_EXECUTABLE="$SINGULAR_BIN_DIR/Singular"
. "$srcdir/test.sh"
