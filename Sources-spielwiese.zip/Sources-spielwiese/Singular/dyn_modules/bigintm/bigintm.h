#ifndef BIGINTM_H
#define BIGINTM_H

BOOLEAN bigintm_setup();

#endif
