#!/bin/sh

# env

# "$SINGULAR_EXECUTABLE" -teq "$srcdir/bigintm.tst"
