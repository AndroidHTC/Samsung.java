#!/bin/sh

export SINGULAR_EXECUTABLE="$SINGULAR_BIN_DIR/Singularg"
. "$srcdir/test.sh"

