#ifndef CALLGFANLIB_TROPICALVARIETY_H
#define CALLGFANLIB_TROPICALVARIETY_H

BOOLEAN tropicalVariety(leftv res, leftv args);

#endif
