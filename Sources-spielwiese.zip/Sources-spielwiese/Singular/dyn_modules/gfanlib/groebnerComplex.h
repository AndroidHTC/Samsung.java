#ifndef GFANLIB_GROEBNERCOMPLEX_H
#define GFANLIB_GROEBNERCOMPLEX_H

BOOLEAN groebnerComplex(leftv res, leftv args);

#endif
