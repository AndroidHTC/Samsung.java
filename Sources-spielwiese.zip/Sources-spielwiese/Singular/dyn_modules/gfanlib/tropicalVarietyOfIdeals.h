#ifndef CALLGfANLIB_TROPICALVARIETYOFIDEALS
#define CALLGfANLIB_TROPICALVARIETYOFIDEALS

#include <polys/simpleideals.h>
#include <tropicalStrategy.h>

gfan::ZFan* tropicalVariety(const tropicalStrategy currentStrategy);

#endif
