#ifndef LIFT_H
#define LIFT_H

#include <polys/simpleideals.h>

ideal lift(const ideal I, const ring r, const ideal inI, const ring s);

#endif
