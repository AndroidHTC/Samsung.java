#ifndef POLYMAKE_DOCUMENTATION_H
#define POLYMAKE_DOCUMENTATION_H

#include <kernel/mod2.h>

#ifdef HAVE_POLYMAKE

void init_polymake_help();

#endif
#endif
