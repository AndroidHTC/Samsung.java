#ifndef TEMPTEST_HPP
#define TEMPTEST_HPP

//Temporary testfunction to play arround with new functions
//NOTE: remove later
bigintmat* temp_test(bigintmat& a);

number temp_test2(number a);


#endif
