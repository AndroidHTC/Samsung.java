/****************************************
 * Computer Algebra System SINGULAR     *
 ****************************************/
/***************************************************************
 * File:    pipeLink.h
 *  Purpose: declaration of sl_link routines for pipe
 ***************************************************************/
#ifndef PIPELINK_H
#define PIPELINK_H
si_link_extension slInitPipeExtension(si_link_extension s);
#endif

