toc:
- title: About the Samples
  path: /samples/index.html

- title: What's New
  path: /samples/new/index.html

<?cs var:samples_toc_tree ?>