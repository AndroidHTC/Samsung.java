package com.android.stubs;
public enum SomeEnum
{
A(),
B(),
C();
}
