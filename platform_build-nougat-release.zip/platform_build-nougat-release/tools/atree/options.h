#ifndef OPTIONS_H
#define OPTIONS_H

#include <string>
#include <vector>

using namespace std;

extern vector<string> g_listFiles;
extern vector<string> g_inputBases;
extern string g_outputBase;
extern bool g_useHardLinks;

#endif // OPTIONS_H
